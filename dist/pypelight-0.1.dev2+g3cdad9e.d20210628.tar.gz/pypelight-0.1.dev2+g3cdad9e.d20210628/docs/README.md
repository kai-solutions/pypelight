# etl tools

# Toolset created for maximizing efficiency on creating ETL pipelines using Python
# Supports quick and controllable flows
# Steps to install package:
	# Open up a terminal (Anaconda Prompt works good)
	# Change path to etl_tools
	# Install using setup.py. Command is: pip install .
	
# Developed by Heinz Stecher Monge. Business Intelligence Specialist